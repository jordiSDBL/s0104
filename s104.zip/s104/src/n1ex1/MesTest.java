package n1ex1;

import static org.junit.Assert.*;
import java.util.LinkedList;
import org.junit.*;

import main.Main;

public class MesTest {

	int[] arrayProva = new int[3];

	static LinkedList<String> mesos;

	/**
	 * Abans de comen�ar amb les proves, que empleni el LinkedList igual que ho fa
	 * el programa. Nom�s ho far� una vegada.
	 */
	@BeforeClass
	public static void beforeClass() {
		System.out.println("Executa el beforeClass()");
		String[] mesosAny = { "gener", "febrer", "mar�", "abril", "maig", "juny", "juliol", "agost", "setembre",
				"octubre", "novembre", "desembre" };
		mesos = Main.inserir(mesosAny);
	}

	/**
	 * Comprovarem que el size() de la llista sigui 12
	 */
	@Test
	public void comprovarPosicions() {
		System.out.println("Executa comprovarPosicions()");
		assertEquals(12, mesos.size());
	}

	/**
	 * Comprovarem a la vuitena posici�, index 7, la cadena sigui "agost"
	 */
	@Test
	public void comprovarAgost() {
		System.out.println("Executa comprovarAgost()");
		assertEquals("agost", mesos.get(7));

	}

	/**
	 * Comprovem que la llista no estigui buida
	 */
	@Test
	public void comprovarNotNull() {
		System.out.println("Executa comprovarNotNull()");
		assertNotNull(mesos);
	}
}
