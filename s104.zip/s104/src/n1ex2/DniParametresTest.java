package n1ex2;

import static org.junit.Assert.*;

import java.util.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

/**
 * @RunWith perqu� el compilador s�piga que ha de buscar un m�tode dins de la
 *          classe que passar� par�metres als m�todes @Test que facin �s dels
 *          atributs de la classe
 */
@RunWith(value = Parameterized.class)
public class DniParametresTest {
	// variables
	private int num;
	private char esperat;

	// constructor
	public DniParametresTest(int num, char esperat) {
		this.num = num;
		this.esperat = esperat;
	}

	/**
	 * Retorna una llista d�objectes on dins de cada un hi ha les combinacions de
	 * par�metres que es vol passar.
	 * 
	 * @return
	 */
	@Parameters
	public static Iterable<Object[]> getData() {
		return Arrays.asList(new Object[][] { { 47883357, 'W' }, { 41158605, 'J' }, { 41486777, 'K' },
				{ 42123505, 'V' }, { 42747805, 'M' }, { 42010905, 'W' }, { 42016807, 'Q' }, { 48597107, 'Q' },
				{ 48503215, 'X' }, { 49993210, 'L' } });
	}

	/**
	 * M�tode per calcular la lletra que li pertoca a un n�mero de DNI
	 */
	@Test
	public void testDni() {
		String jocCaracters = "TRWAGMYFPDXBNJZSQVHLCKE";
		int modulo = num % 23;
		char resultat = jocCaracters.charAt(modulo);

		assertEquals(esperat, resultat);
	}

}
