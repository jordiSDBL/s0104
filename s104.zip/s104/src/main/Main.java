package main;

import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		String[] mesosAny = { "gener", "febrer", "mar�", "abril", "maig", "juny", "juliol", "agost", "setembre",
				"octubre", "novembre", "desembre" };

		inserir(mesosAny);
	}

	static public LinkedList<String> inserir(String[] mesosAny) {
		LinkedList<String> mesos = new LinkedList<String>();
		for (int i = 0; i < mesosAny.length; i++) {
			mesos.add(mesosAny[i]);
		}

		return mesos;
	}

	static public void recorrer(int[] array, int n) {
		if (n > 0) {
			throw new ArrayIndexOutOfBoundsException("No hi ha tantes posicions per rec�rrer.");
		}
		for (int i = 0; i < array.length + n; i++) {
			System.out.println("Fa una interaci�");
		}

	}

}
