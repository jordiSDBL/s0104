package n1ex3;

import org.junit.*;

import main.Main;

public class ExcepcioTest {

	static int[] arrayProva;

	@Before
	public void before() {
		arrayProva = new int[3];
	}

	/**
	 * Comprova que quan es passa un valor major que 0 al segon par�metre, es llanci
	 * l'excepci� ArrayIndexOutOfBoundsException
	 * Cal passar el par�metre expected a @Test amb el nom de la classe
	 * que s�espera que es llanci.
	 */
	@Test(expected = ArrayIndexOutOfBoundsException.class)
	public void recorrerTest() {
		Main.recorrer(arrayProva, 1);
	}
}
